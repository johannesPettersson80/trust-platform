use smol_str::SmolStr;

use crate::memory::{InstanceId, IoArea, MemoryLocation};
use crate::value::{ref_indices_from_iter, RefSegment as ValueRefSegment, Value, ValueRef};

use crate::bytecode::{RefEntry, RefLocation, RefSegment};

use super::util::normalize_name;
use super::util::to_u32;
use super::{BytecodeEncoder, BytecodeError, CodegenContext};

impl<'a> BytecodeEncoder<'a> {
    pub(super) fn resolve_lvalue_ref(
        &self,
        ctx: &CodegenContext,
        target: &crate::program_model::LValue,
    ) -> Result<Option<ValueRef>, BytecodeError> {
        use crate::program_model::LValue;
        if target.contains_index() {
            return Ok(None);
        }
        if let Some(qualified) = target.qualified_name() {
            if let Some(reference) = self.resolve_name_ref(ctx, &qualified)? {
                return Ok(Some(reference));
            }
        }
        match target {
            LValue::Name(name) => self.resolve_name_ref(ctx, name),
            LValue::Index { target, indices } => {
                let Some(mut reference) = self.resolve_lvalue_ref(ctx, target)? else {
                    return Ok(None);
                };
                let Some(resolved) = literal_indices(indices)? else {
                    return Ok(None);
                };
                reference
                    .path
                    .push(crate::value::RefSegment::Index(ref_indices_from_iter(
                        resolved,
                    )));
                Ok(Some(reference))
            }
            LValue::Field { target, field } => {
                let Some(mut reference) = self.resolve_lvalue_ref(ctx, target)? else {
                    return Ok(None);
                };
                reference
                    .path
                    .push(crate::value::RefSegment::Field(field.clone()));
                Ok(Some(reference))
            }
            LValue::Deref(_) => Ok(None),
        }
    }

    pub(super) fn resolve_name_ref(
        &self,
        ctx: &CodegenContext,
        name: &SmolStr,
    ) -> Result<Option<ValueRef>, BytecodeError> {
        let key = normalize_name(name);
        if let Some(reference) = ctx.local_ref(name) {
            return Ok(Some(reference.clone()));
        }
        if let Some(reference) = ctx.static_ref(name) {
            return Ok(Some(reference.clone()));
        }
        if self.authoring.is_some() {
            if let Some(reference) = ctx
                .instance_id
                .and_then(|id| self.construction.bindings.instance(id, name))
            {
                return Ok(Some(reference.clone()));
            }
            let global = self.construction.bindings.global(name);
            if let Some(alias) = self.construction.aliases.get(&key) {
                if global.is_some() {
                    return Err(BytecodeError::InvalidSection(
                        "access alias conflicts with global".into(),
                    ));
                }
                if alias.partial.is_none() {
                    return Ok(Some(alias.reference.clone()));
                }
            }
            return Ok(global.cloned());
        }
        if let Some(instance_id) = ctx.instance_id {
            if let Some(reference) = self
                .runtime
                .storage()
                .ref_for_instance_recursive(instance_id, name.as_ref())
                .or_else(|| {
                    (key != *name).then(|| {
                        self.runtime
                            .storage()
                            .ref_for_instance_recursive(instance_id, key.as_ref())
                    })?
                })
            {
                return Ok(Some(reference));
            }
        }
        let access_binding = self
            .runtime
            .access_map()
            .get(name.as_ref())
            .or_else(|| (key != *name).then(|| self.runtime.access_map().get(key.as_ref()))?);
        let global_ref = self
            .runtime
            .storage()
            .ref_for_global(name.as_ref())
            .or_else(|| {
                (key != *name).then(|| self.runtime.storage().ref_for_global(key.as_ref()))?
            });
        if let Some(binding) = access_binding {
            if binding.partial.is_none() {
                if global_ref.is_some() {
                    return Err(BytecodeError::InvalidSection(
                        format!(
                            "VAR_ACCESS declaration '{}' conflicts with a global declaration",
                            binding.name
                        )
                        .into(),
                    ));
                }
                return Ok(Some(binding.reference.clone()));
            }
        }
        Ok(global_ref)
    }

    pub(super) fn ref_index_for(&mut self, value_ref: &ValueRef) -> Result<u32, BytecodeError> {
        if let Some(idx) = self.ref_map.get(value_ref) {
            return Ok(*idx);
        }
        let (location, owner_id) = match value_ref.location {
            MemoryLocation::Global => (RefLocation::Global, 0),
            MemoryLocation::Local(frame) => match self.construction.bodies.result_frames.get(&frame) {
                Some(initializer) => (RefLocation::InitializerResult, *initializer),
                None => (RefLocation::Local, frame.0),
            },
            MemoryLocation::Instance(InstanceId(id)) => (RefLocation::Instance, id),
            MemoryLocation::Retain => (RefLocation::Retain, 0),
            MemoryLocation::Io(area) => {
                let owner = match area {
                    IoArea::Input => 0,
                    IoArea::Output => 1,
                    IoArea::Memory => 2,
                };
                (RefLocation::Io, owner)
            }
        };
        let offset = to_u32(value_ref.offset, "ref offset")?;
        let mut segments = Vec::new();
        for segment in &value_ref.path {
            match segment {
                ValueRefSegment::Index(indices) => {
                    segments.push(RefSegment::Index(indices.to_vec()));
                }
                ValueRefSegment::Field(name) => {
                    let name_idx = self.strings.intern(name.clone());
                    segments.push(RefSegment::Field { name_idx });
                }
            }
        }
        let entry = RefEntry {
            location,
            owner_id,
            offset,
            segments,
        };
        let idx = self.ref_entries.len() as u32;
        self.ref_entries.push(entry);
        self.ref_map.insert(value_ref.clone(), idx);
        Ok(idx)
    }
}

fn literal_indices(
    indices: &[crate::program_model::Expr],
) -> Result<Option<Vec<i64>>, BytecodeError> {
    let mut resolved = Vec::with_capacity(indices.len());
    for expr in indices {
        let value = match expr {
            crate::program_model::Expr::Literal(value) => value,
            _ => return Ok(None),
        };
        let index = match value {
            Value::SInt(v) => i64::from(*v),
            Value::Int(v) => i64::from(*v),
            Value::DInt(v) => i64::from(*v),
            Value::LInt(v) => *v,
            Value::USInt(v) => i64::from(*v),
            Value::UInt(v) => i64::from(*v),
            Value::UDInt(v) => i64::from(*v),
            Value::ULInt(v) => i64::try_from(*v)
                .map_err(|_| BytecodeError::InvalidSection("index literal overflow".into()))?,
            Value::Byte(v) => i64::from(*v),
            Value::Word(v) => i64::from(*v),
            Value::DWord(v) => i64::from(*v),
            Value::LWord(v) => i64::try_from(*v)
                .map_err(|_| BytecodeError::InvalidSection("index literal overflow".into()))?,
            _ => return Ok(None),
        };
        resolved.push(index);
    }
    Ok(Some(resolved))
}

#[cfg(test)]
mod tests {
    use super::literal_indices;
    use crate::program_model::Expr;
    use crate::value::Value;

    #[test]
    fn literal_indices_preserve_integer_widths_and_reject_nonliteral_or_overflow() {
        let indices = [
            Expr::Literal(Value::SInt(-1)),
            Expr::Literal(Value::Int(-2)),
            Expr::Literal(Value::DInt(-3)),
            Expr::Literal(Value::LInt(-4)),
            Expr::Literal(Value::USInt(1)),
            Expr::Literal(Value::UInt(2)),
            Expr::Literal(Value::UDInt(3)),
            Expr::Literal(Value::ULInt(4)),
            Expr::Literal(Value::Byte(5)),
            Expr::Literal(Value::Word(6)),
            Expr::Literal(Value::DWord(7)),
            Expr::Literal(Value::LWord(8)),
        ];
        assert_eq!(
            literal_indices(&indices).expect("integer indices"),
            Some(vec![-1, -2, -3, -4, 1, 2, 3, 4, 5, 6, 7, 8])
        );
        assert_eq!(
            literal_indices(&[Expr::Name("dynamic".into())]).expect("dynamic index"),
            None
        );
        assert_eq!(
            literal_indices(&[Expr::Literal(Value::Bool(true))]).expect("BOOL index"),
            None
        );

        let overflow = literal_indices(&[Expr::Literal(Value::ULInt(u64::MAX))])
            .expect_err("ULINT above i64 must fail");
        assert!(overflow.to_string().contains("index literal overflow"));
    }
}
